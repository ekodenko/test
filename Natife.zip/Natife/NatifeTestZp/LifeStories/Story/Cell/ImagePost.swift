//
//  ImagePost.swift
//  LifeStories
//
//  Created by Alexey on 29.07.2021.
//

import UIKit

class ImagePost: UICollectionViewCell {

    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var imageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

}
