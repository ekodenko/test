//
//  StoryViewController+Delegate.swift
//  LifeStories
//
//  Created by Alexey on 29.07.2021.
//

import UIKit

extension StoryViewController: UICollectionViewDelegate {
    
}
